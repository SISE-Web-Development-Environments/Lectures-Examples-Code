// const s = new Date().getSeconds();

// const loop_seconds = 3;

// setTimeout(function () {
//   // prints out "3", meaning that the callback is not called immediately after 500 milliseconds.
//   console.log("Ran after " + (new Date().getSeconds() - s) + " seconds");
// }, 500);

// console.log("Hold on... start looping");
// while (true) {
//   if (new Date().getSeconds() - s >= loop_seconds) {
//     console.log("Good, looped for " + loop_seconds + " seconds");
//     break;
//   }
// }
